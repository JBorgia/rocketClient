package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPQLClientStore {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT c.firstName, c.lastName, a.city "
				+ "FROM Customer AS c " 
				+ "JOIN c.store AS s "
				+ "JOIN s.address AS a "
				+ "WHERE s.id=?1";
		List<Object[]> customers = em.createQuery(q, Object[].class).setParameter(1, 1).getResultList();
		for (Object[] customer : customers) {
			for (Object object : customer) {
				System.out.print(object.toString() + " ");
			}
			System.out.println();
		}

		em.close();
		emf.close();

	}
}
