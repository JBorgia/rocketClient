package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPQLClientRentalHistory {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT c.firstName, c.lastName, r.id, r.rentalDate, r.returnDate " 
				+ "FROM Rental AS r " 
				+ "JOIN r.customer AS c "
				+ "WHERE c.id=?1";
		List<Object[]> customers = em.createQuery(q, Object[].class).setParameter(1, 1).getResultList();
		for (Object[] customer : customers) {
			for (Object object : customer) {
				System.out.print(object.toString() + " ");
			}
			System.out.println();
		}

		em.close();
		emf.close();

	}
}
