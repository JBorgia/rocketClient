package client;

import javax.persistence.*;

import entities.Actor;

public class UpdateActor {
	public static void main(String[] args) {

		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();

		Actor a = em.find(Actor.class, 201);
		a.setLastName("Stallone");
		System.out.println(a);

		em.getTransaction().begin();
		em.getTransaction().commit();
		
		em.close();
	}
}