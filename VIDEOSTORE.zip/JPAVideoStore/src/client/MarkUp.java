package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import entities.Film;

public class MarkUp {
	public static void main(String[] args) {

		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();

		double newRate = 1.49;
		String q = "SELECT f " + "FROM Film AS f " + "WHERE f.rentalRate<?1";
		List<Film> f = em.createQuery(q, Film.class).setParameter(1, 1.00).getResultList();
		for (Film film : f) {
			film.setRentalRate(newRate);
		}

		em.getTransaction().begin();
		em.getTransaction().commit();
		
		for (Film film : f) {
			System.out.println(film.getTitle() + " " + film.getRentalRate());
		}

		em.close();
	}
}