package client;

import javax.persistence.*;

import entities.Actor;

public class DestroyActor {
	public static void main(String[] args) {
		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();

		Actor a = em.find(Actor.class, 202);
		System.out.println(a);

		em.remove(a);
		System.out.println(a);

		em.getTransaction().begin();
		em.getTransaction().commit();
		a = em.find(Actor.class, 201);

		System.out.println(a);

		em.close();
	}
}