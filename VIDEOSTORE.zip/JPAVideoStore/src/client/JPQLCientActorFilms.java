package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Film;

public class JPQLCientActorFilms {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT a.id, f " 
				+ "FROM Actor AS a "
				+ "JOIN a.films AS f "
				+ "WHERE a.id = ?1";
		List<Object[]> actorFilms = em.createQuery(q, Object[].class).setParameter(1, 1).getResultList();
			for (Object[] objects : actorFilms) {
					System.out.println(objects[0] + " " + objects[1]);
			}

		em.close();
		emf.close();
	}
}
