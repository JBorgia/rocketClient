package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPQLClientCustomer1Rentals {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT c.id, c.firstName, c.lastName, r.rentalDate "
				+ "FROM Rental AS r " 
				+ "JOIN r.customer AS c " 
				+ "WHERE c.id = ?1";
		List<Object[]> customers = em.createQuery(q, Object[].class).setParameter(1, 1)
				.getResultList();
		for (Object[] customer : customers) {
			for (Object object : customer) {
				System.out.print(object.toString() + " ");
			}
			System.out.println();
		}
		System.out.println(customers.size());

		em.close();
		emf.close();

	}
}
