package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Category;
import entities.Film;

public class JPQLClientFilmCategory {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT f " 
				+ "FROM Film AS f " 
				+ "JOIN f.categories AS c " 
				+ "WHERE c.name = ?1 "
				+ "OR c.name = ?2";
		List<Film> HorrorFamilyFilms = em.createQuery(q, Film.class).setParameter(1, "Family").setParameter(2, "Horror").getResultList();
		for (Film film : HorrorFamilyFilms) {
			System.out.print(film.getTitle() + " ");
			for (Category category : film.getCategories()) {
				System.out.println(category.getName());
			}
		}

		em.close();
		emf.close();
	}
}
