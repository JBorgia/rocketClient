package client;

import javax.persistence.*;

import entities.Actor;

public class CreateActor {
	public static void main(String[] args) {

		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();

		Actor a = new Actor();
		a.setFirstName("Troy");
		a.setLastName("McClure");

		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.persist(a);
		
		tx.commit();
		
		System.out.println(a);
		
		em.close();
	}
}