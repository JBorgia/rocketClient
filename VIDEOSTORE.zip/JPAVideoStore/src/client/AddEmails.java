package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import entities.Customer;
import entities.Film;

public class AddEmails {
	public static void main(String[] args) {

		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();

		String q = "SELECT c " 
				+ "FROM Customer AS c " 
				+ "WHERE c.email IS NULL "
				+ "OR c.email<?1 ";
		List<Customer> c = em.createQuery(q, Customer.class).setParameter(1, "").getResultList();
		for (Customer cust : c) {
			cust.setEmail(cust.getFirstName()+"."+cust.getLastName()+"@"+"sdvidcustomer.org");
		}

		em.getTransaction().begin();
		em.getTransaction().commit();
		
		for (Customer cust : c) {
			System.out.println(cust.getEmail());
		}

		em.close();
	}
}