package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.InventoryItem;

public class JPQLClientInventoryItem {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String q = "SELECT s.id, f.title, i.mediaCondition " 
					+ "FROM InventoryItem AS i " 
					+ "JOIN i.film AS f " 
					+ "JOIN i.store AS s "
					+ "WHERE f.title LIKE ?1 "
					+ "AND s.id=?2";
		List<Object[]> InventoryItemStartA = em.createQuery(q, Object[].class).setParameter(1, "A%").setParameter(2, 1).getResultList();
		for (Object[] iI : InventoryItemStartA) {
			System.out.println(iI[0] + " " + iI[1]);
		}
		System.out.println(InventoryItemStartA.size());
//		String q = "SELECT i " 
//				+ "FROM InventoryItem AS i " 
//				+ "JOIN i.film AS f " 
//				+ "WHERE f.title LIKE ?1";
//		List<InventoryItem> InventoryItemStartA = em.createQuery(q, InventoryItem.class).setParameter(1, "A%").getResultList();
//		for (InventoryItem iI : InventoryItemStartA) {
//			System.out.println(iI.getFilm().getTitle() + " " + iI.getMediaCondition());
//		}
//		System.out.println(InventoryItemStartA.size());

		em.close();
		emf.close();
	}
}