package client;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.*;

public class CustomerClient {
	public static void main(String[] args) {
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
//		EntityManager em = emf.createEntityManager();
		EntityManager em = Persistence.createEntityManagerFactory("VideoStore").createEntityManager();
		
		Customer c = em.find(Customer.class, 47);
		Address a = em.find(Address.class, 5);
		Staff e = em.find(Staff.class, 5);
		Language l = em.find(Language.class, 5);
		Film f = em.find(Film.class, 5);
		
		System.out.println(c);
		System.out.println(a);
		System.out.println(e);
		System.out.println(l);
		System.out.println(f);
		
		em.close();
//		emf.close();
	}
}