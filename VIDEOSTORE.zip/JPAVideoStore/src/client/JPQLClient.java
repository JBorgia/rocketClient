package client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPQLClient {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		
//		String q1 = "SELECT staffer FROM Staff AS staffer WHERE staffer.id <10";
//		List<Staff> emps = em.createQuery(q1, Staff.class).getResultList();
//		for (Staff emp : emps) {
//			System.out.println(emp.getLastName());
//		}
		
		String q2 = "SELECT staffer.lastName FROM Staff AS staffer WHERE staffer.id <10";
		List<String> lastNames = em.createQuery(q2, String.class).getResultList();
		for (String string : lastNames) {
			System.out.println(string);
		}
		
		String q3 = "SELECT staffer.id, staffer.firstName, staffer.lastName "
				  + "FROM Staff AS staffer "
				  + "WHERE staffer.id <10";
		List<Object[]> staffers = em.createQuery(q3, Object[].class).getResultList();
		for (Object[] objects : staffers) {
			for (Object object : objects) {
				System.out.print(object + " ");
			}
			System.out.println();
		}
		
		String q4 = "SELECT staffer.id, staffer.firstName, staffer.lastName, staffer.address.country.name "
				  + "FROM Staff AS staffer "
				  + "WHERE staffer.id <?1";
		List<Object[]> staffers2 = em.createQuery(q4, Object[].class)
										.setParameter(1, 40)
										.getResultList();
		for (Object[] objects : staffers2) {
			for (Object object : objects) {
				System.out.print(object + " ");
			}
			System.out.println();
		}
		
		em.close();
		emf.close();
		
	}
}
