package entities;

public enum Rating {
	G, PG, PG13, R, NC17;
}
