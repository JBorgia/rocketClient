package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Country {
//	+--------------+-------------+------+-----+---------+-------+
//	| Field        | Type        | Null | Key | Default | Extra |
//	+--------------+-------------+------+-----+---------+-------+
//	| country_code | char(2)     | NO   | PRI | NULL    |       |
//	| country      | varchar(50) | NO   |     | NULL    |       |
//	| formal_name  | varchar(60) | YES  |     | NULL    |       |
//	| sovereignty  | varchar(30) | YES  |     | NULL    |       |
//	| capital      | varchar(80) | YES  |     | NULL    |       |
//	| iso3_code    | char(3)     | YES  |     | NULL    |       |
//	| tld          | char(3)     | YES  |     | NULL    |       |
//	+--------------+-------------+------+-----+---------+-------+
	
	@Id
	@Column(name = "country_code")
	private String countryCode;
	@Column(name = "country")
	private String name;
	@Column(name = "formal_name")
	private String formalName;
	private String sovereignty;
	private String capital;
	@Column(name = "iso3_code")
	private String iso3Code;
	private String tld;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Country [countryCode=" + countryCode + ", name=" + name + "]";
	}

	public String getFormalName() {
		return formalName;
	}

	public void setFormalName(String formalName) {
		this.formalName = formalName;
	}

	public String getSovereignty() {
		return sovereignty;
	}

	public void setSovereignty(String sovereignty) {
		this.sovereignty = sovereignty;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public String getIso3Code() {
		return iso3Code;
	}

	public void setIso3Code(String iso3Code) {
		this.iso3Code = iso3Code;
	}

	public String getTld() {
		return tld;
	}

	public void setTld(String tld) {
		this.tld = tld;
	}
}