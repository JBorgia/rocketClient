package entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Store {
	// +------------+----------------------+------+-----+---------+----------------+
	// | Field | Type | Null | Key | Default | Extra |
	// +------------+----------------------+------+-----+---------+----------------+
	// | id | smallint(5) unsigned | NO | PRI | NULL | auto_increment |
	// | manager_id | int(10) unsigned | YES | UNI | NULL | |
	// | address_id | int(10) unsigned | NO | UNI | NULL | |
	// +------------+----------------------+------+-----+---------+----------------+

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// @OneToOne(mappedBy = "store")
	private int id;
	@OneToOne
	@JoinColumn(name = "manager_id")
	private Staff manager;
	@OneToOne
	@JoinColumn(name = "address_id")
	private Address address;
	@OneToMany(mappedBy = "store")
	private List<Customer> customers;
	@OneToMany(mappedBy = "store")
	private List<Staff> staffers;
	@ManyToMany
	@JoinTable(name = "inventory_item", joinColumns = @JoinColumn(name = "store_id"), inverseJoinColumns = @JoinColumn(name = "film_id"))
	List<Film> films;
	@OneToMany(mappedBy = "store")
	private List<InventoryItem> inventoryItems;

	public void addInventoryItem(InventoryItem inventoryItem) {
		if (inventoryItems == null) {
			inventoryItems = new ArrayList<>();
		}
		if (!inventoryItems.contains(inventoryItem)) {
			inventoryItems.add(inventoryItem);
			inventoryItem.setStore(this);
		}
	}

	public void removeInventoryItem(InventoryItem inventoryItem) {
		if (inventoryItems != null && inventoryItems.contains(inventoryItem)) {
			inventoryItems.remove(inventoryItem);
			inventoryItem.setStore(null);
		}
	}


	public void addFilm(Film film) {
		if (films == null) {
			films = new ArrayList<>();
		}
		if (!films.contains(film)) {
			films.add(film);
			film.addStore(this);
		}
	}

	public void removeFilm(Film film) {
		film.setStores(null);
		if (staffers != null) {
			staffers.remove(film);
		}
	}

	public void addStaff(Staff staff) {
		if (staffers == null) {
			staffers = new ArrayList<>();
		}
		if (!staffers.contains(staff)) {
			staffers.add(staff);
			if (staff.getStore() != null) {
				staff.getStore().getStaffers().remove(staff);
			}
			staff.setStore(this);
		}
	}

	public void removeStaff(Staff staff) {
		staff.setStore(null);
		if (staffers != null) {
			staffers.remove(staff);
		}
	}


	public void addCustomer(Customer customer) {
		if (customers == null) {
			customers = new ArrayList<>();
		}
		if (!customers.contains(customer)) {
			customers.add(customer);
			if (customer.getStore() != null) {
				customer.getStore().getCustomers().remove(customer);
			}
			customer.setStore(this);
		}
	}

	public void removeCustomer(Customer customer) {
		customer.setStore(null);
		if (customers != null) {
			customers.remove(customer);
		}
	}

	public Staff getManager() {
		return manager;
	}

	public void setManager(Staff managerId) {
		this.manager = managerId;
	}

	public int getId() {
		return id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Store [id=" + id + ", managerId=" + manager + ", address=" + address + "]";
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	public List<Staff> getStaffers() {
		return staffers;
	}

	public void setStaffers(List<Staff> staffers) {
		this.staffers = staffers;
	}

	public List<Film> getFilms() {
		return films;
	}

	public void setFilms(List<Film> films) {
		this.films = films;
	}

}
