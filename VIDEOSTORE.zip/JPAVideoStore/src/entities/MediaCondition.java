package entities;

public enum MediaCondition {
	New, Used, Damaged, Lost, NA;
}
