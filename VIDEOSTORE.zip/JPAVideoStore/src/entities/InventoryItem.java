package entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="inventory_item")
public class InventoryItem {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(name="media_condition")
	@Enumerated(EnumType.STRING)
	private MediaCondition mediaCondition;
	@ManyToOne
	@JoinColumn(name="film_id")
	private Film film;
	@ManyToOne
	@JoinColumn(name="store_id")
	private Store store;
	@OneToMany(mappedBy = "inventoryItem")
	private List<Rental> rentals;

	public void addRental(Rental rental) {
		if (rentals == null) {
			rentals = new ArrayList<>();
		}
		if (!rentals.contains(rental)) {
			rentals.add(rental);
			rental.setInventoryItem(this);
		}
	}

	public void removeRental(Rental rental) {
		if (rentals != null && rentals.contains(rental)) {
			rentals.remove(rental);
			rental.setInventoryItem(null);
		}
	}
	
	public MediaCondition getMediaCondition() {
		return mediaCondition;
	}

	public void setMediaCondition(MediaCondition mediaCondition) {
		this.mediaCondition = mediaCondition;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "InventoryItem [id=" + id + ", mediaCondition=" + mediaCondition + "]";
	}

	public Film getFilm() {
		return film;
	}

	public void setFilm(Film film) {
		this.film = film;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}
}
