package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Address;
import entities.Language;
import entities.Store;

public class StoreTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindStoreObject() throws ParseException {
		Store store = em.find(Store.class, 7);
		assertEquals("27340 El Camino Real", store.getAddress().getStreet());
		assertEquals(null, store.getAddress().getStreet2());
		assertEquals("Los Angeles", store.getAddress().getCity());
		assertEquals("California", store.getAddress().getStateProvince());
		assertEquals("90004", store.getAddress().getPostalCode());
		assertEquals("213 5558265", store.getAddress().getPhone());
		assertEquals(105, store.getCustomers().size());
		assertEquals(12, store.getStaffers().size());
		assertEquals(5, store.getManager().getId());
		assertEquals("Steve", store.getManager().getFirstName());
		assertEquals("Striker", store.getManager().getLastName());
		
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
