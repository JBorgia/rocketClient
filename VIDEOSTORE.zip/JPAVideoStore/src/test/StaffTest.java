package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Staff;

public class StaffTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindStaffObject() throws ParseException {
		Staff staff = em.find(Staff.class, 1);
		assertEquals("Larry", staff.getFirstName());
		assertEquals("Kong", staff.getLastName());
		assertEquals("370 E. Rochelle Blvd", staff.getAddress().getStreet());
		assertEquals(null, staff.getAddress().getStreet2());
		assertEquals("Nevada", staff.getAddress().getStateProvince());
		assertEquals("89191", staff.getAddress().getPostalCode());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
