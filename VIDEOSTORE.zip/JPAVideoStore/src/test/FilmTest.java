package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Customer;
import entities.Film;
import entities.Rating;

public class FilmTest{
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindCustomerObject() throws ParseException {
		Film film = em.find(Film.class, 1);
		assertEquals("ACADEMY DINOSAUR", film.getTitle());
		assertEquals("A Epic Drama of a Feminist And a Mad Scientist who must Battle a Teacher in The Canadian Rockies", film.getDescription());
		assertEquals(1993, film.getReleaseYear());
		assertEquals(0.99, film.getRentalRate(), 0.0001);
		assertEquals(86, film.getLength());
		assertEquals(20.99, film.getReplacementCost(),0.0001);
		assertEquals("PG", film.getRating().toString());
		assertEquals(3, film.getLanguage().getId());
		assertEquals("Japanese", film.getLanguage().getName());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
