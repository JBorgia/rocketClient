package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Address;
import entities.Language;

public class AddressTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindAddressObject() throws ParseException {
		Address add = em.find(Address.class, 605);
		assertEquals("1325 Fukuyama Street", add.getStreet());
		assertEquals("", add.getStreet2());
		assertEquals("Tieli", add.getCity());
		assertEquals("Heilongjiang", add.getStateProvince());
		assertEquals("27107", add.getPostalCode());
		assertEquals("China, People's Republic of", add.getCountry().getName());
		assertEquals("288241215394", add.getPhone());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
