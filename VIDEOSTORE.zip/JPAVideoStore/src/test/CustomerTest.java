package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Address;
import entities.Customer;

public class CustomerTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindCustomerObject() throws ParseException {
		Customer cust = em.find(Customer.class, 1);
		assertEquals("Mary", cust.getFirstName());
		assertEquals("Smithers", cust.getLastName());
		SimpleDateFormat formatter = new SimpleDateFormat("yyy-MM-dd");
		Date expected = formatter.parse("2014-05-25");
		assertEquals(expected, cust.getCreateDate());
		
//		Address add = em.find(Address.class, cust.getAddressId());
//		assertEquals("1913 Hanoi Way", add.getStreet());
//		assertEquals("", add.getStreet2());
//		assertEquals("Sasebo", add.getCity());
//		assertEquals("Nagasaki", add.getStateProvince());
//		assertEquals("35200", add.getPostalCode());
//		assertEquals("28303384290", add.getPhone());
		assertEquals("1913 Hanoi Way", cust.getAddress().getStreet());
		assertEquals("", cust.getAddress().getStreet2());
		assertEquals("Sasebo", cust.getAddress().getCity());
		assertEquals("Nagasaki", cust.getAddress().getStateProvince());
		assertEquals("35200", cust.getAddress().getPostalCode());
		assertEquals("28303384290", cust.getAddress().getPhone());
		
		assertEquals(5, cust.getStore().getManager().getId());

		assertEquals("27340 El Camino Real", cust.getStore().getAddress().getStreet());
		assertEquals(null, cust.getStore().getAddress().getStreet2());
		assertEquals("Los Angeles", cust.getStore().getAddress().getCity());
		assertEquals("California", cust.getStore().getAddress().getStateProvince());
		assertEquals("90004", cust.getStore().getAddress().getPostalCode());
		assertEquals("213 5558265", cust.getStore().getAddress().getPhone());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
