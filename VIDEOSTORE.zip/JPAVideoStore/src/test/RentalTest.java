package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Customer;
import entities.Rental;

public class RentalTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindRentalObject() throws ParseException {
		Rental rental = em.find(Rental.class, 1);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date expected1 = formatter.parse("2014-05-24 22:53:30");
		System.out.println(rental);
		assertEquals(expected1, rental.getRentalDate());
		assertEquals(14072, rental.getInventoryItem().getId());
		assertEquals(130, rental.getCustomer().getId());
		Date expected2 = formatter.parse("2014-05-26 22:04:30");
		assertEquals(expected2, rental.getReturnDate());
		assertEquals(46, rental.getStaff().getId());
		assertEquals("William", rental.getStaff().getFirstName());
		assertEquals("Tingvold", rental.getStaff().getLastName());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
