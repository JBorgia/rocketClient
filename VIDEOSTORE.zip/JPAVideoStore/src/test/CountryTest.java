package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Address;
import entities.Country;
import entities.Language;

public class CountryTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindCountryObject() throws ParseException {
		Country country = em.find(Country.class, "CN");
		assertEquals("CN", country.getCountryCode());
		assertEquals("China, People's Republic of", country.getName());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
