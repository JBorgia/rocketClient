package test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Film;
import entities.Language;

public class LanguageTest {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		em = emf.createEntityManager();
	}

	@Test
	public void testEMFindLanguageObject() throws ParseException {
		Language lang = em.find(Language.class, 3);
		assertEquals("Japanese", lang.getName());
		List<Film> films = lang.getFilms();
		assertEquals(9, films.size());
	}

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
