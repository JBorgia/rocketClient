package dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;

import entities.Customer;


@Transactional
public class VideoDAOJPAImpl implements VideoDAO{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public Customer getCustomer(int id){
		Customer cust = em.find(Customer.class, id);
		return cust;
	}
	
	
	public void addNewCustomer(Customer customer){
		em.persist(customer);
	}

}
