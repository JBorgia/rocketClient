package dao;

import org.springframework.web.servlet.ModelAndView;

import entities.Customer;

public interface VideoDAO {
	public Customer getCustomer(int id);
	public void addNewCustomer(Customer customer);
}
