package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.VideoDAO;
import entities.Customer;

@Controller
public class VideoController {
	@Autowired
	private VideoDAO videoDao;

	@RequestMapping(path = "GetCustomer.do")
	private ModelAndView getCustomer(int id) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("customer.jsp");
		mv.addObject("cust", videoDao.getCustomer(id));
		return mv;
	}
	
	@RequestMapping(path = "AddCustomer.do")
	private ModelAndView addNewCustomer(Customer customer) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("customer.jsp");
		videoDao.addNewCustomer(customer);
		mv.addObject("cust", customer);
		return mv;
	}
	
	
	
}
